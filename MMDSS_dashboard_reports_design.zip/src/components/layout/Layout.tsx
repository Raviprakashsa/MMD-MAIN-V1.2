import React, { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router';
import { 
  LayoutDashboard, 
  Building2, 
  Briefcase, 
  Users, 
  Search, 
  Clock, 
  FileBarChart, 
  Settings,
  Bell,
  Menu,
  ChevronLeft,
  LogOut,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const SidebarItem = ({ icon: Icon, label, to, collapsed }: { icon: any, label: string, to: string, collapsed: boolean }) => {
  return (
    <NavLink
      to={to}
      className={({ isActive }) => `
        flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group relative mb-1
        ${isActive 
          ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/20 font-medium' 
          : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
      `}
    >
      <Icon size={20} className={`shrink-0 ${!collapsed ? '' : 'mx-auto'}`} />
      {!collapsed && (
        <span className="whitespace-nowrap overflow-hidden transition-all duration-300 origin-left text-sm">
          {label}
        </span>
      )}
      {collapsed && (
        <div className="absolute left-full ml-4 px-3 py-1.5 bg-slate-900 text-white text-xs font-medium rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none z-50 whitespace-nowrap shadow-xl border border-slate-700">
          {label}
        </div>
      )}
    </NavLink>
  );
};

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const getPageTitle = () => {
    const path = location.pathname.split('/')[1];
    return path.charAt(0).toUpperCase() + path.slice(1) || 'Dashboard';
  };

  return (
    <div className="flex h-screen bg-slate-50/30 font-sans text-slate-900">
      {/* Sidebar - Updated for Grounding Principle (Dark Theme) */}
      <motion.aside 
        initial={false}
        animate={{ width: collapsed ? 80 : 260 }}
        className="h-screen bg-slate-900 shadow-xl z-30 flex flex-col fixed left-0 top-0 overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1.0)]"
      >
        {/* Logo Area */}
        <div className="h-20 flex items-center px-6 border-b border-slate-800/50 bg-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-indigo-900/50 shrink-0">
              M
            </div>
            {!collapsed && (
              <div className="flex flex-col">
                <span className="font-bold text-lg tracking-tight text-white leading-tight">
                  MMDSS
                </span>
                <span className="text-[10px] font-medium text-slate-500 uppercase tracking-widest">
                  Admin Panel
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto py-6 px-4 flex flex-col gap-1 custom-scrollbar">
          <div className={`px-2 mb-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest ${collapsed ? 'hidden' : 'block'}`}>
            Core Modules
          </div>
          <SidebarItem icon={LayoutDashboard} label="Dashboard" to="/dashboard" collapsed={collapsed} />
          <SidebarItem icon={Users} label="Candidates" to="/candidates" collapsed={collapsed} />
          <SidebarItem icon={Briefcase} label="Requirements" to="/requirements" collapsed={collapsed} />
          <SidebarItem icon={Building2} label="Companies" to="/companies" collapsed={collapsed} />
          
          <div className={`px-2 mt-8 mb-3 text-[10px] font-bold text-slate-500 uppercase tracking-widest ${collapsed ? 'hidden' : 'block'}`}>
            Operations
          </div>
          <SidebarItem icon={Search} label="Leads & Scraping" to="/leads" collapsed={collapsed} />
          <SidebarItem icon={Clock} label="Timesheets" to="/timesheets" collapsed={collapsed} />
          <SidebarItem icon={FileBarChart} label="System Reports" to="/reports" collapsed={collapsed} />
          
          <div className="mt-auto pt-8">
             <SidebarItem icon={Settings} label="Settings" to="/settings" collapsed={collapsed} />
          </div>
        </div>

        {/* User Profile */}
        <div className="p-4 border-t border-slate-800 bg-slate-900">
          <div className={`flex items-center gap-3 p-2 rounded-xl transition-colors ${collapsed ? 'justify-center' : 'hover:bg-slate-800'}`}>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1554765345-6ad6a5417cde?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwb3J0cmFpdCUyMG1hbnxlbnwxfHx8fDE3NzAxMjEwMDd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Admin"
                className="w-9 h-9 rounded-full object-cover border-2 border-slate-700"
              />
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
            </div>
            {!collapsed && (
              <div className="flex-1 overflow-hidden">
                <p className="text-sm font-semibold text-white truncate">Admin User</p>
                <p className="text-xs text-slate-400 truncate">Super Admin</p>
              </div>
            )}
            
            <button 
              onClick={() => setCollapsed(!collapsed)}
              className={`text-slate-500 hover:text-white transition-colors ${collapsed ? 'absolute -right-8 opacity-0' : 'ml-auto'}`}
            >
              <ChevronLeft size={16} />
            </button>
          </div>
          {collapsed && (
             <button 
               onClick={() => setCollapsed(!collapsed)}
               className="w-full flex justify-center mt-2 text-slate-600 hover:text-white"
             >
               <Menu size={16} />
             </button>
          )}
        </div>
      </motion.aside>

      {/* Main Content */}
      <main 
        className="flex-1 flex flex-col min-h-screen transition-all duration-300 ease-[cubic-bezier(0.25,0.1,0.25,1.0)] bg-[#F8FAFC]"
        style={{ marginLeft: collapsed ? 80 : 260 }}
      >
        {/* Header - Glassmorphism */}
        <header className="h-20 bg-white/70 backdrop-blur-xl sticky top-0 z-20 border-b border-slate-200/60 px-8 flex items-center justify-between shadow-[0_4px_20px_-10px_rgba(0,0,0,0.05)]">
          <div>
            <h1 className="text-xl font-bold text-slate-800 tracking-tight">{getPageTitle()}</h1>
            <p className="text-xs text-slate-400 font-medium mt-0.5">Wednesday, Feb 4 • 2026</p>
          </div>
          
          <div className="flex items-center gap-5">
            <div className="relative group hidden md:block">
               <input 
                 type="text" 
                 placeholder="Search MMD-ID, Candidate..." 
                 className="pl-11 pr-4 py-2.5 bg-slate-100/50 border border-slate-200/50 rounded-full text-sm w-72 focus:ring-4 focus:ring-indigo-100 focus:bg-white focus:border-indigo-300 transition-all outline-none placeholder:text-slate-400"
               />
               <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4 group-focus-within:text-indigo-500 transition-colors" />
            </div>
            
            <button className="relative p-2.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-all">
              <Bell size={20} />
              <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white ring-2 ring-white"></span>
            </button>
            
            <div className="h-8 w-[1px] bg-slate-200 mx-1"></div>
            
            <button className="bg-slate-900 hover:bg-slate-800 text-white px-5 py-2.5 rounded-xl text-sm font-semibold flex items-center gap-2 shadow-lg shadow-slate-200 transition-all active:scale-95 hover:shadow-xl">
              <Plus size={16} />
              <span>Quick Action</span>
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-8 flex-1 overflow-y-auto">
          <Outlet />
        </div>
      </main>
    </div>
  );
}