import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Candidates from './pages/Candidates';
import Companies from './pages/Companies';
import Requirements from './pages/Requirements';
import Leads from './pages/Leads';
import Timesheets from './pages/Timesheets';
import Reports from './pages/Reports';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="companies" element={<Companies />} />
          <Route path="requirements" element={<Requirements />} />
          <Route path="candidates" element={<Candidates />} />
          <Route path="leads" element={<Leads />} />
          <Route path="timesheets" element={<Timesheets />} />
          <Route path="reports" element={<Reports />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;