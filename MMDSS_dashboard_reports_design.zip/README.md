
  # MMDSS_dashboard_reports_design

  This is a code bundle for MMDSS_dashboard_reports_design. The original project is available at https://www.figma.com/design/9aPFouyhaSazJNQn2l1vmg/MMDSS_dashboard_reports_design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  